-- Active: 1700019936290@@127.0.0.1@3306@projekkantin
/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     30/11/2023 23:56:46                          */
/*==============================================================*/
-- ATTENTION!!!! ATTENTION!!!
-- agar tidak error kalian jalankan drop DATABASE namaDatabaseKalian
-- habis itu CREATE DATABASE namaDatabaseKalian
-- habis itu silahkan jalankan semua
use projekkantin;

drop table if exists DETAIL_TRANSAKSI;

drop table if exists PRODUK;

drop table if exists SUPPLIER;

drop table if exists TRANSAKSI;

drop table if exists TRANSAKSI_SUPPLIER;

drop table if exists USER;

/*==============================================================*/
/* Table: DETAIL_TRANSAKSI                                      */
/*==============================================================*/
create table DETAIL_TRANSAKSI
(
   ID_DETAIL_TRANSAKSI  int not null,
   ID_PRODUK            int,
   ID_TRANSAKSI         int,
   QTY                  int,
   HARGA                decimal(10,3),
   SUB_TOTAL            decimal(10,3),
   primary key (ID_DETAIL_TRANSAKSI)
);

/*==============================================================*/
/* Table: PRODUK                                                */
/*==============================================================*/
create table PRODUK
(
   ID_PRODUK            int not null,
   NAMA_PRODUK          varchar(100) not null,
   KATEGORI             varchar(100) not null,
   STOK                 int not null,
   HARGA_JUAL           decimal(10,3) not null,
   primary key (ID_PRODUK)
);

/*==============================================================*/
/* Table: SUPPLIER                                              */
/*==============================================================*/
create table SUPPLIER
(
   ID_SUPPLIER          int not null,
   NAMA_SUPPLIER        varchar(100) not null,
   NO_TELP              varchar(15),
   primary key (ID_SUPPLIER)
);

/*==============================================================*/
/* Table: TRANSAKSI                                             */
/*==============================================================*/
create table TRANSAKSI
(
   ID_TRANSAKSI         int not null,
   ID_USER              int,
   JENIS_PEMBAYARAN     varchar(20) not null,
   TGL_TRANSAKSI        date not null,
   JUMLAH_BAYAR         decimal(10,3),
   SISA_BAYAR           decimal(10,3),
   TOTAL_HARGA          decimal(10,3),
   primary key (ID_TRANSAKSI)
);

/*==============================================================*/
/* Table: TRANSAKSI_SUPPLIER                                    */
/*==============================================================*/
create table TRANSAKSI_SUPPLIER
(
   ID_TRANSAKSI_SUPPLIER int not null,
   ID_PRODUK            int,
   ID_SUPPLIER          int,
   HARGA_SUPPLIER       decimal(10,3) not null,
   JUMLAH_PRODUK        int not null,
   TGL_SUPPLY           date not null,
   RETUR                decimal(10,3),
   primary key (ID_TRANSAKSI_SUPPLIER)
);

/*==============================================================*/
/* Table: USER                                                  */
/*==============================================================*/
create table USER
(
   ID_USER              int not null,
   USERNAME             varchar(50),
   PASSWORD             varchar(50),
   LEVEL                enum('pemilik','kasir') not null,
   primary key (ID_USER)
);

alter table DETAIL_TRANSAKSI add constraint FK_MEMILIKI foreign key (ID_TRANSAKSI)
      references TRANSAKSI (ID_TRANSAKSI) on delete restrict on update restrict;

alter table DETAIL_TRANSAKSI add constraint FK_TERLIBAT foreign key (ID_PRODUK)
      references PRODUK (ID_PRODUK) on delete restrict on update restrict;

alter table TRANSAKSI add constraint FK_MELAYANI foreign key (ID_USER)
      references USER (ID_USER) on delete restrict on update restrict;

alter table TRANSAKSI_SUPPLIER add constraint FK_MELAKUKAN foreign key (ID_SUPPLIER)
      references SUPPLIER (ID_SUPPLIER) on delete restrict on update restrict;

alter table TRANSAKSI_SUPPLIER add constraint FK_MELIBATKAN foreign key (ID_PRODUK)
      references PRODUK (ID_PRODUK) on delete restrict on update restrict;

