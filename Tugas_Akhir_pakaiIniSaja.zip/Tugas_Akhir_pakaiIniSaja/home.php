
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card mb-4">
          <div class="card-body">
            <h5 class="card-title">Card 1</h5>
            <p class="card-text">Isi konten untuk Card 1 disini.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card mb-4">
          <div class="card-body">
            <h5 class="card-title">Card 2</h5>
            <p class="card-text">Isi konten untuk Card 2 disini.</p>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <div class="graph-box">
            <h4>Grafik dari hasil penjualan</h4>
          <!-- Grafik atau konten lainnya akan ditempatkan di sini -->
        </div>
      </div>
    </div>
  </div>

    <?php
    // require 'menu.php';
    ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
