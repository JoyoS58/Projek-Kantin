<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="styleHeader.css">
  <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />
</head>
<body>
  <div class="header">
        <i class="bx bx-menu menu-icon" style="margin-right: 50px;"></i>
        <h1 style="margin-top: 10px;">SIKAN</h1>
  </div>
</body>
</html>