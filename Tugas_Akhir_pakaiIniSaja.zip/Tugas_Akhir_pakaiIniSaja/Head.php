<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- <title>Document</title> -->
  <link rel="stylesheet" href="components/css/styleHeaderKasir.css">
  <title>Halaman dengan Card dan Grafik</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link
      href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha384-xrR63EePpceL92V6RDAxR9VKT/xotb8QFh9Yv+1Iw0FvEpFf4W/wD01TsqgxU0jp" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- menyisipkan javascript -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="components/css/styleSidebarKasir.css">
    <link rel="stylesheet" href="components/css/styleHomeKasir.css">
</head>
<body>
  <div class="header">
        <i class="bx bx-menu menu-icon" style="margin-right: 50px;"></i>
        <h4 style="margin-top: 10px;">SIKAN</h4>
  </div>
  <?php
  // require 'menu.php';
  ?>
