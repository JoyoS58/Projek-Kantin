<?php
require_once('config/koneksi.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['Username'];
    $password = $_POST['Password'];

    $db = new Database();
    $conn = $db->getConnection();

    // Lakukan proses validasi login
    $query = "SELECT * FROM users WHERE username = $username AND password = $password";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Set session untuk user yang berhasil login
        $_SESSION['username'] = $user['username'];
        $_SESSION['level'] = $user['level'];

        // Arahkan pengguna ke halaman berdasarkan rolenya
        if ($_SESSION['level'] === 'kasir') {
            header("Location: ../User/Kasir/home.php");
            exit();
        } elseif ($_SESSION['role'] === 'pemilik') {
            header("Location: User/Pemilik/home.php");
            exit();
        }
    } else {
        // Tambahkan pesan kesalahan jika login gagal
        $_SESSION['login_error'] = "Username atau password salah!";
        header("Location: login.php");
        exit();
    }
} else {
    // Jika tidak ada data POST
    header("Location: login.php");
    exit();
}
?>
