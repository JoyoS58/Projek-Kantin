<?php
session_start();

if (isset($_SESSION['username']) && isset($_SESSION['level'])) {
    if ($_SESSION['level'] === 'Kasir') {
        header("Location: User/Kasir/home.php");
        exit();
    } elseif ($_SESSION['role'] === 'pemilik') {
        header("Location: pemilik_dashboard.php");
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?>
